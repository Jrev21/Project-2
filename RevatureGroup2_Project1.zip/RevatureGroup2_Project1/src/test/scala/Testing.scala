//import org.apache.spark.sql.SparkSession
//import org.apache.spark.{SparkConf, SparkContext}
//
//object Testing {
//  def main(args: Array[String]): Unit = {
//    System.setProperty("hadoop.home.dir", "C:\\Hadoop\\bin")
//
//      val spark = SparkSession
//        .builder()
//        .appName("RevatureGroup2_Project1")
//        .config("spark.master", "local")
//        .enableHiveSupport()
//        .getOrCreate()
//
//    System.setProperty("hadoop.home.dir", "C:\\hadoop")
//
//      println("Starting Spark Session")
//
////      val lines = spark.sparkContext.parallelize(
////        Seq("Spark IntelliJ Idea Scala test one",
////          "Spark IntelliJ Idea Scala test two",
////          "Spark IntelliJ Idea Scala test three"))
////
////      val counts1 = lines
////        .flatMap(line => line.split(" "))
////        .map(word => (word, 1))
////        .reduceByKey(_ + _)
////
////      counts1.foreach(println)
////
//      //Create a SparkContext to initialize Spark
//      val conf = new SparkConf()
//      conf.setMaster("local")
//      conf.setAppName("Word Count example")
//      val sc = new SparkContext(conf)
////
////      // Load the text into a Spark RDD, which is a distributed representation of each line of text
////      val textFile = sc.textFile("src/input/Dataset.csv")
////
////      //word count
////      val counts2 = textFile.flatMap(line => line.split(" "))
////        .map(word => (word, 1))
////        .reduceByKey(_ + _)
////
////      counts2.foreach(println)
////      System.out.println("Total words: " + counts2.count())
////      counts2.saveAsTextFile("src/output/SparkWordCountData2")
//
//      val sampleSeq = Seq((1, "Spark"), (2, "Big Data"))
//      val sampleDF = spark.createDataFrame(sampleSeq).toDF("Course ID", "Course Name")
//      sampleDF.show()
//      sampleDF.write.format("csv").save("C:\\sampleSeq")
//
//      val df = spark.read.csv("src/input/Dataset.csv").toDF(
//        "Order_ID", "Customer_ID", "Name", "Product_ID", "Product_name",
//        "Product_type", "Qty", "Price", "Datetime", "Country", "City", "Ecommerce_website_name",
//        "Payment_txn_id", "Payment_txn_success", "Failure_reason")
//      df.show(5)
//
//      df.printSchema()
//
//      df.select("Name","Product_name").show()
//
//      println("Spark Session ended")
//
//      spark.stop()
//  }

//
import scala.io.StdIn

//object DatabaseMenu {
//
//  val databaseManager = new ecommerce_app.DatabaseManager
//
//  def main(args: Array[String]): Unit = {
//
//    Init()
//    menu_selection()
//  }
//
//  def Init(): Unit = {
//    databaseManager.createDatabase()
//  }
//  //      //print the menu
//  //      print_menu()
//  //      //used a infinite iterator to read the input of a user and
//  //      Iterator.continually(StdIn.readLine())
//  //        //exit the iterator if 0 was inputted
//  //        .takeWhile(_ != "0" )
//  //        // would parse the input for one of the options on the menu
//  //        .foreach{
//  //          case "0" => println ("case 0: End Program")
//  //          case "1" => println("Case 1: First Query")
//  //          case "2" => println("Case 2: Second Query")
//  //          case "3" => println("Case 3: Third Query")
//  //          case "4" => println("Case 4: Fourth Query")
//  //          case other => "not an option"
//  //        }
//  //      def print_menu() {
//  //        //menu would print the options to the user
//  //        // i used a map since i could print it out using there keys
//  //        val menu_options = Map(
//  //          0 -> "Exit",
//  //          1 -> "Case 1",
//  //          2 -> "Case 2",
//  //          3 -> "Case 3",
//  //          4 -> "Case 4"
//  //        )
//  //        //would print the map out along with the keys
//  //        menu_options.keys.foreach { i =>
//  //          println(i + " --- " + menu_options(i))
//  //        }
//  //      }
//  def menu_selection(): Unit = {
//    try {
//      print("========================")
//      print(
//        """
//          |0: Quit Program
//          |1: First Data Analysis
//          |2: Second Data Analysis
//          |3: Third Data Analysis
//          |4: Fourth Data Analysis
//          |""".stripMargin)
//      println("========================")
//      chooseAnalysis(readLine("Please choose scenario: ").toInt)
//      println(" ")
//    }
//    catch {
//      case e: Exception => println("Please choose from existing choices. " +
//        "Current Exception(s):\n" + e.printStackTrace())
//        println("========================")
//        menu_selection()
//    }
//  }
//  def chooseAnalysis(x: Int) : Unit = x match {
//    case 1 => queryNumber(x)
//    //          case 2 => queryNumber(x)
//    //          case 3 => queryThree(x)
//    //          case 4 => queryFour(x)
//  }
//
//  def executeQuery(queryNumber: String): Unit = queryNumber match {
//    case "m1q1" =>
//      println(
//        """
//          |0: Go Back
//          |1: What is the top selling category of items?
//          |2: Per country?
//          |""".stripMargin)
//      queryResult(readLine("Select number: ").toInt)
//
//      def queryResult(x: Int): Unit = x match {
//        case 1 => databaseManager.marketingQuestions("m1q1")
//      }
//    Example query
//    val productDF = spark.sql("SELECT * FROM orders WHERE product_name = 'bike'")
//    productDF.show(10)
//  }
//"Order_ID", "Customer_ID", "Customer_Name", "Product_ID", "Product_name", "Product_category",
//"Qty", "Product_price", "Datetime", "Country", "City", "Ecommerce_website_name",
//"Payment_txn_id", "Payment_txn_success", "Failure_reason")
//}
