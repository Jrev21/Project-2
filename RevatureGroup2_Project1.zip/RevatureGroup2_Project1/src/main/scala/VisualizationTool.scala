//import org.apache.spark.sql.SparkSession
//import vegas._
//import vegas.sparkExt._
//import vegas.render.WindowRenderer._
//import vegas.data.External._
//object VisualizationTool {
//  def main(args: Array[String]): Unit = {
//    val spark = SparkSession
//      .builder()
//      .appName("RevatureGroup2_Project1")
//      .config("spark.master", "local")
//      .getOrCreate()
//
//      println("Starting Spark Session")
//      val plot = Vegas("Country Pop").
//        withData(
//          Seq(
//            Map("country" -> "USA", "population" -> 314),
//            Map("country" -> "UK", "population" -> 64),
//            Map("country" -> "DK", "population" -> 80)
//          )
//        ).
//        encodeX("country", Nom).
//        encodeY("population", Quant).
//        mark(Bar)
//
//      plot.show
//
//      def renderWindow = {
//        plot.window.show
//      }
//
//
//      def renderHTML = {
//        println(plot.html.frameHTML("foo")) // an iframe containing the plot
//      }
//
//      renderHTML
//
//      renderWindow
//
//      // to specify a function that receives the SpecBuilder instead, use vegas.render.ShowRender.using
//      implicit val renderer = vegas.render.ShowRender.using(sb => println(s"The SpecBuilder is $sb"))
//  }
//}
