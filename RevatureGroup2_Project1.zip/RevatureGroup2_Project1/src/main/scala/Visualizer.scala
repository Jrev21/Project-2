import vegas._
import vegas.sparkExt._

object Visualizer {

  def main(args: Array[String]): Unit = {

    val plot = Vegas("Country Pop").
      withData(
        Seq(
          Map("country" -> "USA", "population" -> 314),
          Map("country" -> "UK", "population" -> 64),
          Map("country" -> "DK", "population" -> 80)
        )
      ).
      encodeX("country", Nom).
      encodeY("population", Quant).
      mark(Bar)

    def renderWindow = {
      plot.window.show
    }

    implicit val render = vegas.render.ShowHTML(s => print("%html " + s))

//    renderWindow
  }
}
