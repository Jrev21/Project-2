import org.apache.spark.sql._
import org.apache.spark.sql.functions._

class DataAnalysis {
  //Example query
  //val productDF = spark.sql("SELECT * FROM orders WHERE product_name = 'bike'")
  //productDF.show(10)

  def getTopSellingCategoryOfItems(spark: SparkSession): Unit = {


  val topSellerDF = spark.sql("SELECT Product_category, Country, SUM(Qty) FROM Orders WHERE " +
    "GROUP BY Qty, Product_category, Country")
    .toDF("Product Category", "Country","Products Sold")
    topSellerDF.show()
  }

//  def getChangeOfPopularityThroughoutYear: Unit ={
//    val popularityChangeThroughoutYear = spark.sql("SELECT ")
//  }
}
