import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import vegas._
import vegas.sparkExt._
import vegas.DSL.{ExtendedUnitSpecBuilder, UnitSpecBuilder}

class DataAnalysis {

  //Example query
  //val productDF = spark.sql("SELECT * FROM orders WHERE product_name = 'bike'")
  //productDF.show(10)

  def getTopSellingCategoryOfItems(spark: SparkSession): Unit = {
    val topSellerDF = spark.sql("SELECT Product_category, SUM(Qty) FROM Orders " +
      "GROUP BY Product_category")
      .toDF("Product_category","Products_sold")


    topSellerDF.show()

    val topSellerByCountryDF = spark.sql("SELECT Product_category, Country, SUM(Qty) FROM Orders WHERE " +
      "GROUP BY QTY, Product_category, Country")
      .toDF("Product_category", "Country","Products_sold")

    topSellerByCountryDF.show()
  }

  def getChangeOfPopularityThroughoutYear(spark: SparkSession): Unit = {
    val popularityChangeDF = spark.sql("SELECT * FROM Orders")
      popularityChangeDF.groupBy("Datetime", "Country", "Product_type")
        .count().orderBy("Country", "Datetime")

    popularityChangeDF.show()
  }

  def getLocationsForHighestTrafficOfSales(spark: SparkSession): Unit = {
    val trafficSalesDF = spark.sql("SELECT City, COUNT(Qty) " +
      "FROM Orders GROUP BY City")
      .toDF("City", "Locations_with_Highest_Sales")

      trafficSalesDF.sort("Locations_with_Highest_Sales").show()
  }

//  def getTimesForHighestTrafficOfSales(spark: SparkSession): Unit = {
//    val trafficSalesTimesDF = spark.sql("SELECT Datetime, SUM(Qty) " +
//      "FROM Orders GROUP BY Datetime")
//      .toDF("Datetime", "Total_Product_Sold")
//      .sort("Total_Products_Sold")
//
//      trafficSalesTimesDF.show()

//    val trafficSalesCountryDF = spark.sql("SELECT country, Datetime, SUM(Qty) " +
//      "FROM Orders GROUP BY Country, Datetime")
//      .toDF("Country","Datetime", "Total_Sold")
//      .sort("Country")
//    trafficSalesCountryDF.show()
  }
}
