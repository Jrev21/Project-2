import org.apache.spark.sql.SparkSession

class DatabaseManager {


  //utilize winutils.exe for running Hadoop on Windows
  System.setProperty("hadoop.home.dir", "C:\\Hadoop\\bin")

  val dataAnalysis = new DataAnalysis

  //create SparkSession
  val spark = SparkSession
    .builder ()
    .appName ("E-commerce_Big_Data_App")
    .config ("spark.master", "local")
    //Disabled Hive temporarily while putting this together
    //    .enableHiveSupport()
    .getOrCreate()

  println("Spark session initialized.")


  def createDatabase(): Unit = {

    val df = spark.read
      .format("csv")
      .option("inferSchema", "true")
      .option("header", "true")
      .csv("src/input/Dataset_with_errors.csv")
      .toDF("Order_ID", "Customer_ID", "Customer_Name", "Product_ID", "Product_name", "Product_category",
               "Product_type", "Qty", "Price", "Datetime", "Country", "City", "Ecommerce_website_name",
               "Payment_txn_id", "Payment_txn_success", "Failure_reason")


    //printed as example
//    df.printSchema()
//    df.show(5)

    //create lazily evaluated table for queries
    df.createOrReplaceTempView("orders")

  }

  //end Spark session
  def closeSpark(): Unit = {
    println("Spark Session closed")
    spark.close
  }

  //queries for the data analysis questions
  def marketingQuestions(marketingQuestionNumber: String): Unit = marketingQuestionNumber match {
    //What is the top selling category of items? Per country?
    case "m1q1" => dataAnalysis.getTopSellingCategoryOfItems(spark)
//    case "two" => queryTwo.getChangeOfPopularityThroughoutYear(spark)
//    case "three" => queryThree.getLocationsForHighestTrafficOfSales(spark)
//    case "four" => queryFour.getTimesForHighestTrafficOfSales(spark)
  }

  def returnSparkSession(): SparkSession = {
    spark
  }

}
