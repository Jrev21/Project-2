import org.apache.spark
import scala.io.StdIn
import vegas._
import vegas.sparkExt._
import vegas.DSL.{ExtendedUnitSpecBuilder, UnitSpecBuilder}
import org.apache.log4j.Logger
import org.apache.log4j.Level

object DatabaseMenu {
  //utilize winutils.exe for running Hadoop on Windows
  System.setProperty("hadoop.home.dir", "C:\\Hadoop\\bin")

  //turn off log messages
  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)

  val databaseManager = new DatabaseManager

  def main(args: Array[String]): Unit = {

    Init()
    menu()

  }

  def Init(): Unit = {
    databaseManager.createDatabase()
  }

  def menu(): Unit ={
    //parser for the loop statement
    var condition = true
    do{
      println("Welcome to the Project Database Management Menu")
      println("-----------------------------------------------")
      print_menu()
      println("-----------------------------------------------")
      println("Please select an option from the menu:")
      try {
        //val input will take an input from a user based on the menu
        val input = scala.io.StdIn.readLine()
        input match {//println for now but each case would then go to the operation of there choosing
          case "1" => databaseManager.marketingQuestions("one")
          case "2" => databaseManager.marketingQuestions( "two")
          case "3" => databaseManager.marketingQuestions( "three")
          case "4" => databaseManager.marketingQuestions( "four")
          case "0" => {
            println("Goodbye"); condition = false;
          } // would exit the program
          case other  => println("Invalid option") // if a invalid option was inputted
        }
        // try and catch was used just in case we found any errors down the road
      }catch{
        case e: IllegalArgumentException => {
          println("error")
        }
      }
    } while(condition)
  }
  def print_menu() {

    //menu would print the options to the user
    // I used a map since I could print it out using its keys
    val menu_options = Map(
      1 -> "Top Selling Categories of Items",
      2 -> "Product Popularity Change Throughout the Year",
      3 -> "Highest Traffic of Sales by Location",
      4 -> "Times during the year with the Highest Traffic of Sales",
      0 -> "Exit"
    )

    //would print the map out along with the keys
    menu_options.keys.foreach { i =>
      println(i + " --- " + menu_options(i))
    }
  }
}
