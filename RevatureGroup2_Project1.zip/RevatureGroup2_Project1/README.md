# RevatureGroup2_Project1
A Big Data Technology Project that utilizes Spark SQL to query and analyze 10,000 e-commerce records generated in a .csv file. 
The members of this team include: Julio Ortiz, Michael Celusniak, Juan Sandoval, Raymond Fu, and Christiana Dickson
